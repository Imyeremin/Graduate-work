(function initPage() {
    document.addEventListener('DOMContentLoaded', () => {
        initSwiper();
        initPinkEnum();
        initWhyBlocks();
    });
    
    function initSwiper() {
        const tabs = Array.from(document.getElementsByClassName('js-supervisor-block-tab'));
        const isDesktop = window.screen.width > 1160;
        const swiper = new Swiper('#supervisor-swiper', {
            direction: 'horizontal',
            speed: 700,
            spaceBetween: isDesktop ? 20 : 0,
            slidesPerView: isDesktop
                ? 1
                : 1.14,
            mousewheel: { forceToAxis: true }
        });
    
        swiper.on('activeIndexChange', () => {
            tabs.forEach(el => {
                const slideId = parseInt(el.getAttribute('slideId'));
                const markedAsActive = el.classList.contains('active');
                if (swiper.activeIndex === slideId) {
                    if (!markedAsActive) {
                        el.classList.add('active');
                    }
                } else if (markedAsActive) {
                    el.classList.remove('active');
                }
            })
        })
    
        tabs.forEach((el) => {
            const slideId = parseInt(el.getAttribute('slideId'));
            el.addEventListener('click', () => swiper.slideTo(slideId))
        })
    
        document.getElementById('supervisor-block-cards').classList.add('ready');
    }
    
    function initPinkEnum() {
        window.addEventListener("scroll", function () {
            var elementTarget = document.getElementById("why-block");
            if (window.scrollY + window.screen.height > (elementTarget.offsetTop)) {
                document.getElementById('based-block-title').classList.add('active');
            }
        });
    
        new Swiper('#enum-animation', {
            direction: 'vertical',
            speed: 800,
            autoHeight: true,
            loop: true,
            autoplay: {
                delay: 800,
            },
        });
    }
    
    function initWhyBlocks() {
        window.addEventListener("scroll", function () {
            var elementTarget = document.getElementById("why-block-cards");
            if (window.scrollY + window.screen.height > (elementTarget.offsetTop)) {
                Array.from(document.getElementsByClassName('why-block__card')).forEach(el => el.classList.add('expanded'));
            }
        });
    }    
})()

function firstAnimationPhotoReady() {
    setTimeout(() => {
        new Swiper('#main-animation-photo', {
            speed: 1000,
            loop: true,
            autoplay: {
                delay: 6500,
            },
        });
        document.getElementById('main-animation-block')?.classList.remove('not-ready')
    }, 1000);
}
