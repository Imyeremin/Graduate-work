(function initPage() {
    document.addEventListener('DOMContentLoaded', () => {
        initSweetScroll();
        initHeader();
    });

    function initHeader() {
        const header = document.getElementById('header');
        if (!header) {
            return;
        }
    
        processHeaderStyles();
        window.addEventListener('scroll', processHeaderStyles);
    
        initMenuDialog();
    
        function processHeaderStyles() {
            if (!header) {
                return;
            }
    
            if (window.scrollY > 30) {
                header.classList.add('scroll');
            } else {
                header.classList.remove('scroll');
            }
        }
    
        function initMenuDialog() {
            const headerMenuButton = document.querySelector('#header-menu-button');
            const menuDialog = document.getElementById('menu-dialog');
            if (!headerMenuButton || !menuDialog) {
                console.error('ошибка инита хедера')
                return;
            }
    
            const openMenuDialog = () => menuDialog?.classList.add('opened');
            const closeMenuDialog = () => menuDialog?.classList.remove('opened')
    
            headerMenuButton?.addEventListener('click', () => openMenuDialog());
    
            menuDialog.querySelectorAll('.menu-dialog__link, .menu-dialog__button, #menu-dialog-close').forEach(link => {
                link.addEventListener('click', () => closeMenuDialog());
            })
        }
    }
    
    function initSweetScroll() {
        function getHeaderElemHeight() {
            return document.getElementById('header')?.clientHeight ?? 0;
        }
    
        new SweetScroll({
            duration: 1500,
            offset: getHeaderElemHeight() * -1,
            updateURL: true
        });
    }
})()


function openTryDialog() {
    const dialog = document.getElementById('try-dialog');
    openDialog(dialog);
}

function openExpertDialog() {
    const dialog = document.getElementById('expert-dialog');
    openDialog(dialog);
}

function openDialog(dialogElem) {
    dialogElem.classList.add('opened');
    document.body.classList.add('dialog-opened');
    
}

function closeDialog(buttonElem) {
    buttonElem.closest('dialog')?.classList.remove('opened');
    document.body.classList.remove('dialog-opened');
}
