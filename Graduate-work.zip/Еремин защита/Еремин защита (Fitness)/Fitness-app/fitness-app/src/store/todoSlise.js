import { createSlice } from "@reduxjs/toolkit";

const todoSlice = createSlice({
  name: "todo",
  initialState: {
    todos: [
      {
        id: new Date().toISOString() + 1,
        task: "Составить план занятий",
        date: "20.10.2024 10:00",
        desc: "Для самого себя"},
      {
        id: new Date().toISOString() + 2,
        task: "Проверить тренеровку Екатерины Ивановой",
        date: "19.12.2024 12:00",
        desc: "Посмотреть результаты тренеровки и дать обратную связь клиенту касаемо выполнения" },
      {
        id: new Date().toISOString() + 3,
        task: "Назначить тренеровку Ивановой",
        date: "18.12.2024 10:00",
        desc: "Назначить упражнение для Кати на все группы мышц" },
    ],
  },
  reducers: {
    addTodo(state, action) {
      state.todos.push({
        ...action.payload,
        id: new Date().toISOString(),
      });
    },
    deleteTodo(state, action) {
      state.todos = state.todos.filter((todo) => todo.id !== action.payload);
    },
  },
});

export const { addTodo, deleteTodo } = todoSlice.actions;

export default todoSlice.reducer;
