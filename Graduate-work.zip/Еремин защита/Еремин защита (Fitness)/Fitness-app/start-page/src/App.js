import logo from './logo.svg';
import './App.css';
import StartPage from './page/StartPage';

function App() {
  return (
<StartPage/>
  );
}

export default App;
